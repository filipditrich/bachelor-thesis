/**
 * 🍏 Various brand logo icons icons barrel exports
 * BarrelGun: auto-generated barrel file, do not edit!
 */

export { default as PaypalSmallLogo } from './paypal-small.svg';
export { default as MastercardSmallLogo } from './mastercard-small.svg';
export { default as ApplePaySmallLogo } from './apple-pay-small.svg';

/**
 * 🧩 DefinitionItem component barrel exports
 * BarrelGun: auto-generated barrel file, do not edit!
 */

export * from './DefinitionItem.types';
export * from './DefinitionItem';

/**
 * 🧩 TicketCard component barrel exports
 * BarrelGun: auto-generated barrel file, do not edit!
 */

export * from './TicketCard.types';
export * from './TicketCard';

/**
 * 🧩 SeatingMap component barrel exports
 * BarrelGun: auto-generated barrel file, do not edit!
 */

export * from './SeatingMap.types';
export * from './SeatingMap';

## Seating map project
> This project is a part of bachelor thesis "Web-based ticketing solution with seat reservation" at Unicorn University.
> The thesis is available at: https://github.com/filipditrich/bachelor-thesis.

### Goal of the project
The goal of the project is to create a web application that will allow users to select and buy seats with tickets at some venue. The application will be implemented only from the frontend perspective, the backend will be mocked.

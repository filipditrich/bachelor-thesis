/**
 * PostCSS configuration
 * @type {import("postcss").Processor}
 */
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
